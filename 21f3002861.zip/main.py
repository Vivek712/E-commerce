import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import render_template
from flask import request

current_dir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///" + os.path.join(current_dir, "database.sqlite3") 
db = SQLAlchemy()
db.init_app(app)
app.app_context().push()

class Student(db.Model):
   __tablename__ ="student"
   student_id=db.Column(db.Integer,primary_key=True,autoincrement=True)
   roll_number=db.Column(db.String(100),unique=True,nullable=False)
   first_name=db.Column(db.String(100),nullable=False)
   last_name=db.Column(db.String(100))

class Course(db.Model):
    __tablename__ ="course"
    course_id=db.Column(db.Integer,primary_key=True,autoincrement=True)
    course_code=db.Column(db.Integer,unique=True,nullable=False)
    course_name=db.Column(db.String(100), nullable=False)
    course_description=db.Column(db.String(500))

class Enrollments(db.Model):
    __tablename__ = "enrollments"
    enrollment_id=db.Column(db.Integer,primary_key=True,autoincrement=True)
    estudent_id=db.Column(db.Integer,db.ForeignKey("student.student_id"))
    ecourse_id=db.Column(db.Integer,db.ForeignKey("course.course_id"))


# db.create_all();
# course1=Course(course_code='CSE01',course_name='MAD 1',course_description='Modern Application Development - I');
# course2=Course(course_code='CSE02',course_name='DBMS',course_description='Database management Systems');
# course3=Course(course_code='CSE03',course_name='PDSA',course_description='Programming, Data Structures and Algorithms using Python');
# course4=Course(course_code='BST13',course_name='BDM',course_description='Business data Management');

# db.session.add(course1);
# db.session.add(course2);
# db.session.add(course3);
# db.session.add(course4);
# db.session.commit();
#request.form.getlist('mycheckboxes')

def courseIdConverter(list):
    print("Recieved List--->\n",list)
    for i in range(len(list)):
        if(list[i]=='course_1'):
            list[i]=1;
        if(list[i]=='course_2'):
            list[i]=2;    
        if(list[i]=='course_3'):
            list[i]=3;   
        if(list[i]=='course_4'):
            list[i]=4;
    print("Modified List\n-->",list)        
    return list;   


@app.route("/student/create", methods=["GET", "POST"])
def createStudent():
    if request.method == "GET":
        return render_template("addStudent.html")
    if request.method =="POST":
        roll_num=request.form['roll'];
        f_name=request.form['f_name'];
        l_name=request.form['l_name'];
        course_name=request.form.getlist('courses');
        print(roll_num)
        print(f_name)
        print(course_name)
        exists = db.session.query(db.session.query(Student).filter_by(roll_number=roll_num).exists()).scalar();
        if(exists):
            return render_template('alreadyExist.html')
        else:
            rollnumber=roll_num    
            student_add=Student(roll_number=roll_num,first_name=f_name,last_name=l_name)
            db.session.add(student_add);
            db.session.commit();
            print("Before executing this query")
            print("RollNumber==", rollnumber)
            fStu=Student.query.filter_by(roll_number=rollnumber).first();
            print("FStudent--?-->",fStu.student_id)
            newlist=courseIdConverter(course_name);
            for row in newlist:
                enroll=Enrollments(estudent_id=fStu.student_id,ecourse_id=row)
                db.session.add(enroll)
            db.session.commit();
            allStudents=Student.query.all();  
            return render_template('allStudents.html',allStudents=allStudents)


@app.route("/", methods=["GET"])
def getAllStudents():
    allStudents=Student.query.all();  
    if(len(allStudents)==0):
        return render_template('noStudent.html')
    return render_template('allStudents.html',allStudents=allStudents)


@app.route("/student/<int:student_id>/update", methods=["GET", "POST"])
def updateStudent(student_id):
    id=int(student_id)
    print("ID Recevied is ----->",id)
    if request.method == "GET":    
        print("Inside the GET Upate method")
        print(student_id,"---StudentID----")
        
        # fs=Student.query.filter_by(student_id=id).first();
        fs=Student.query.get(id);
        return render_template('updateStudent.html',student_id=fs.student_id,current_roll=fs.roll_number,current_f_name=fs.first_name,current_l_name =fs.last_name)
    if request.method=="POST":
        f_name=request.form['f_name'];
        l_name=request.form['l_name'];
        course_name=request.form.getlist('courses');
        fs=Student.query.get(id);
        fs.first_name=f_name;
        fs.last_name=l_name;
        fs.course_name=course_name;

        courseUpdateInEnrollment=Enrollments.query.filter_by(estudent_id=id).all();
        print("Course Update Enrollment query-->\n",courseUpdateInEnrollment)
        for s in courseUpdateInEnrollment:
            db.session.delete(s);
        db.session.commit();    
        updatedCourseList=courseIdConverter(course_name);

        for row in updatedCourseList:
                enroll=Enrollments(estudent_id=id,ecourse_id=row)
                db.session.add(enroll)
        db.session.commit();
        allStudents=Student.query.all();  
        return render_template('allStudents.html',allStudents=allStudents)



@app.route("/student/<int:student_id>/delete", methods=["GET", "POST"])
def deleteStudent(student_id):
    if request.method=="GET":
        id=int(student_id)
        fs=Student.query.get(id);
        delEnrollCourse=Enrollments.query.filter_by(estudent_id=id).all();
        for s in delEnrollCourse:
            db.session.delete(s);
        db.session.commit();  

        db.session.delete(fs);
        db.session.commit();
        allStudents=Student.query.all();
        if(len(allStudents)==0):
            return render_template('noStudent.html')
        return render_template('allStudents.html',allStudents=allStudents)


@app.route("/student/<int:student_id>", methods=["GET"])
def showDetailStudent(student_id):
    id=int(student_id)
    print("Receibing student id-->\n",id)
    studentDetail=Student.query.get(id);
    enrolledCourse=Enrollments.query.filter_by(estudent_id=id).all();
    courseList=[];
    for row in enrolledCourse:
        courseList.append(row.ecourse_id)
    print("Course Taken Lis--->\n",courseList);    
    courseTakenList=[];
    for cid in courseList:
        cor=Course.query.get(cid)
        courseTakenList.append(cor);
    print("Data from coures table----\n",courseTakenList)
    return render_template('singleStudent.html',studentDetail=studentDetail,courseDetail=courseTakenList)          
app.run(
    debug=True,
    port=8080
  )
